create
    definer = root@localhost procedure PROC_CREATESTUDENT(IN nameNew varchar(255), IN ageNew int, IN genNew bit,
                                                          IN addressNew varchar(255))
begin
    INSERT INTO Student ( name, age, gen, address) values (nameNew,ageNew,genNew,addressNew);
end;

