create
    definer = root@localhost procedure PROC_FindProductById(IN proId int)
begin
        SELECT * from product where id =proId;
    end;

