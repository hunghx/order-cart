create
    definer = root@localhost procedure PROC_ClearCartDetail(IN orderId int)
begin
    delete  from OrderDetail where order_id = orderId;
end;

