create
    definer = root@localhost procedure PROC_FindProductByPage(IN pageNumber int, IN countP int)
begin
    declare startNumber int;
    set startNumber = (pageNumber-1)*countP;
    select  * from  Product limit startNumber,countP;
end;

