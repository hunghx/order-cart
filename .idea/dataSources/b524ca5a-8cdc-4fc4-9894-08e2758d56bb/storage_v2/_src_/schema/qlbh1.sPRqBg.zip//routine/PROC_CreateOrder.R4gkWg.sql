create
    definer = root@localhost procedure PROC_CreateOrder(IN cartId int, IN totalU double, IN phoneU varchar(11),
                                                        IN addressU varchar(255))
begin
    declare userId int ;
    select user_id into userId from Orders where orderId = cartId;
    update Orders set type = 1,total=totalU,phone=phoneU,address=addressU, createdDate=now() where orderId=cartId;
    insert into Orders(user_id,type) values (userId,0);
end;

