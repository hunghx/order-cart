create
    definer = root@localhost procedure findListOrderByUserId(IN userid int)
begin
    select * from orders where  user_id = userid;
end;

