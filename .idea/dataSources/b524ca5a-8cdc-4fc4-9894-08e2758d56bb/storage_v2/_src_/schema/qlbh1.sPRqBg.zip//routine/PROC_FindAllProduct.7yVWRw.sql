create
    definer = root@localhost procedure PROC_FindAllProduct()
begin
    select  * from Product;
end;

