create
    definer = root@localhost procedure PROC_REGISTER(IN user varchar(255), IN pass varchar(100))
begin
    declare userIdLast int;
    INSERT INTO Accounts(username, password) value (user,pass);
     select distinct last_insert_id() into userIdLast from  Accounts;
    INSERT INTO Orders(user_id,type) values (userIdLast,0);
end;

