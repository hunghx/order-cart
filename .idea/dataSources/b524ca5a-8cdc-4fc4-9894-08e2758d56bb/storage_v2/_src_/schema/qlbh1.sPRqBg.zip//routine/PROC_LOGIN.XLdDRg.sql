create
    definer = root@localhost procedure PROC_LOGIN(IN user varchar(255), IN pass varchar(100))
begin
    SELECT a.*,o.orderId from Accounts a right join orders o on a.id=o.user_id where a.username like user and a.password like pass and o.type=0;
end;

