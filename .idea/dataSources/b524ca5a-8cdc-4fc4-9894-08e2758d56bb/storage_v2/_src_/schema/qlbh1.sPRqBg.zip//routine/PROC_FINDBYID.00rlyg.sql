create
    definer = root@localhost procedure PROC_FINDBYID(IN idSearch int)
begin
    select * from Student where id = idSearch;
end;

