create
    definer = root@localhost procedure PROC_CREATENEWORDER(IN cartId int, IN phoneUp varchar(11),
                                                           IN addressUp varchar(255), OUT newCartId int)
begin
    declare  userId int;
    select user_id into userId from orders where orderId = cartId;
    update Orders set type=1,phone = phoneUp,address =addressUp,createdDate = now() where orderId = cartId;
    insert into orders(user_id,type) values (userId,0);
    select  distinct last_insert_id() into newCartId from orders;
end;

