create
    definer = root@localhost procedure PROC_CreateOrderDetail(IN orderId int, IN productId int, IN productPrice float,
                                                              IN productQuantity int)
begin
    insert into OrderDetail(order_id, product_id, product_price, quantity)
        values (orderId,productId,productPrice,productQuantity);
end;

