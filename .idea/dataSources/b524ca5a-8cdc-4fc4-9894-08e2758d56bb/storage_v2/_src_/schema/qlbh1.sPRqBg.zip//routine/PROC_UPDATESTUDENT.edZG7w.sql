create
    definer = root@localhost procedure PROC_UPDATESTUDENT(IN idUp int, IN nameUp varchar(255), IN ageUp int,
                                                          IN genUp bit, IN addressUp varchar(255))
begin
    UPDATE Student set name =nameUp, age=ageUp,gen =genUp,address=addressUp where  id =idUp;
end;

