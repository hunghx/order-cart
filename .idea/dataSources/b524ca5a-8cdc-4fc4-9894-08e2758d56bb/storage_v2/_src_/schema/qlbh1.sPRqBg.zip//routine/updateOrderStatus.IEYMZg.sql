create
    definer = root@localhost procedure updateOrderStatus(IN orderidU int, IN statusU tinyint)
begin
    update orders set status =statusU where  orderId=orderidU;
end;

